"""Create a 24 × 32 inch PDF and an editable SVG from the same drawing commands."""
import base64, html, io, json
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
from reportlab.graphics.barcode.qr import QrCodeWidget

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'poster';OUT.mkdir(exist_ok=True)
W=1728
H=2304
for name,file in [('Regular','LiberationSans-Regular.ttf'),('Bold','LiberationSans-Bold.ttf'),('Serif','LiberationSerif-Regular.ttf'),('Display','LiberationSerif-Bold.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(ROOT/'site/assets/fonts'/file)))
INK='#20343A';MUTED='#59665F';PAPER='#F5F2E9';BLUE='#073A55';LINE='#CCD3C7';TEAL='#4E7568';RUST='#B15B38';GOLD='#AE813B';WHITE='#FFFFFF';GREY='#A2ACA0'
c=canvas.Canvas(str(OUT/'Under_Observation_Poster_24x32.pdf'),pagesize=(W,H));c.setTitle('Under Observation — Maitreyee Singh');c.setAuthor('Maitreyee Singh')
svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="24in" height="32in" viewBox="0 0 {W} {H}">']
font_css=[]
for file,family,weight in [('LiberationSans-Regular.ttf','Liberation Sans',400),('LiberationSans-Bold.ttf','Liberation Sans',700),('LiberationSerif-Regular.ttf','Liberation Serif',400),('LiberationSerif-Bold.ttf','Liberation Serif',700)]:
    raw=(ROOT/'site/assets/fonts'/file).read_bytes()
    font_css.append(f'@font-face{{font-family:"{family}";font-weight:{weight};src:url(data:font/ttf;base64,{base64.b64encode(raw).decode()}) format("truetype")}}')
svg.append('<defs><style>'+''.join(font_css)+'</style></defs>')

def rect(x,y,w,h,fill,stroke=None,sw=1):
    c.setFillColor(fill);c.setStrokeColor(stroke or fill);c.setLineWidth(sw);c.rect(x,H-y-h,w,h,fill=1,stroke=int(bool(stroke)))
    svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke or "none"}" stroke-width="{sw}"/>')
def line(x1,y1,x2,y2,color=LINE,sw=1):
    c.setStrokeColor(color);c.setLineWidth(sw);c.line(x1,H-y1,x2,H-y2)
    svg.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{sw}"/>')
def text(x,y,t,size=20,font='Regular',color=INK):
    c.setFillColor(color);c.setFont(font,size);c.drawString(x,H-y-size,t)
    family='Liberation Serif' if font in ['Serif','Display'] else 'Liberation Sans';weight='700' if font in ['Bold','Display'] else '400'
    svg.append(f'<text x="{x}" y="{y+size}" font-size="{size}" font-family="{family},sans-serif" font-weight="{weight}" fill="{color}">{html.escape(t)}</text>')
def para(x,y,t,width,size=20,leading=None,font='Regular',color=INK):
    leading=leading or size*1.42;lines=[]
    for paragraph in t.split('\n'):
        current=''
        for word in paragraph.split():
            candidate=(current+' '+word).strip()
            if pdfmetrics.stringWidth(candidate,font,size)>width and current:lines.append(current);current=word
            else:current=candidate
        lines.append(current)
    for i,l in enumerate(lines):text(x,y+i*leading,l,size,font,color)
    return y+len(lines)*leading
def image(x,y,w,h,path):
    raw=Path(path).read_bytes();c.drawImage(ImageReader(io.BytesIO(raw)),x,H-y-h,w,h,mask='auto',preserveAspectRatio=False)
    mime='image/jpeg' if Path(path).suffix.lower() in ['.jpg','.jpeg'] else 'image/png'
    svg.append(f'<image x="{x}" y="{y}" width="{w}" height="{h}" href="data:{mime};base64,{base64.b64encode(raw).decode()}"/>')
def heading(x,y,n,t,width):
    text(x,y,n,16,'Bold',TEAL);return para(x,y+30,t,width,31,38,'Bold')

analysis=json.loads((ROOT/'results/behavior.json').read_text())
sur=json.loads((ROOT/'results/communication_surrogate.json').read_text())
rect(0,0,W,H,PAPER);rect(0,0,W,280,WHITE)
text(48,25,'MONITORING CUES, EXPLANATION FIDELITY AND EPISTEMIC RESPONSIBILITY',15,'Bold',TEAL)
text(48,55,'Under Observation',83,'Display',BLUE)
text(49,156,'Do AI agents change their communication when monitoring changes?',31,'Regular',INK)
text(49,211,'Maitreyee Singh   /   Duke University   /   Explainable AI',23,'Regular',INK)
text(49,247,'MARA / TRUST Lab     Project lead: Shreya Mendi     PI: Dr. Bent',18,'Bold',BLUE)
image(1315,56,360,360*181/473,ROOT/'site/assets/duke-science-society-horizontal.jpg')
text(1334,210,'90 games   3 conditions',17,'Bold',TEAL)
line(48,280,1680,280,BLUE,2)

rect(48,313,1632,122,'#E5EBE4')
text(73,336,'WHY TEST THIS?',20,'Bold',TEAL)
para(375,330,'A system can mention oversight without showing that monitoring improves its conduct. Evaluators need to compare the agent’s account with an independent record of what it does.',1250,25,35)

text(48,477,'1   The experiment',35,'Bold')
image(48,542,790,790*1286/2048,ROOT/'site/assets/catanist-interface.png')
para(48,1055,'Shared Catanist interface, supplied by the lab. This illustrates the environment, not one of the selected episodes.',790,17,24,color=MUTED)
text(914,537,'Four Qwen3.8-27B agents play Catan',29,'Bold')
y=para(914,585,'They trade resources and build to earn points. The engine retains statements, generated notes, actions and true resource holdings.',766,24,33)
y+=24
for label,desc,col in [('Auditor stops','Active before turn 60; offline afterward.',RUST),('Auditor continues','Active throughout; replay viewer stops instead.',GOLD),('Auditor starts','Offline before turn 60; active afterward.',TEAL)]:
    rect(914,y+3,4,64,col);text(934,y,label,25,'Bold');text(934,y+36,desc,21,color=MUTED);y+=96
para(914,y+7,'30 games per condition, using the same 20 board seeds. The announcement arrives at turn 60. Independent research records continue throughout.',766,22,31)
line(48,1136,1680,1136,LINE)

left=48;right=914
text(left,1172,'2   What changed?',35,'Bold')
para(left,1230,'75 of 5,650 checked claims about the speaker’s own resources were classified as false.',790,25,34)
chart_y=1330;axis_left=left+170;axis_right=left+686
sx=lambda v:axis_left+v/2.5*(axis_right-axis_left)
for v in [0,1,2]:
    line(sx(v),chart_y+33,sx(v),chart_y+291,LINE)
    text(sx(v)-9,chart_y+302,str(v)+'%',19,color=MUTED)
for i,(arm,label,col) in enumerate(zip(['off_switch','placebo','on_switch'],['Auditor stops','Continues','Auditor starts'],[RUST,GOLD,TEAL])):
    r=analysis['arms'][arm];y=chart_y+57+i*85
    b=100*r['hand_statements_false_before']/r['hand_statements_checked_before']
    a=100*r['hand_statements_false_after']/r['hand_statements_checked_after']
    text(left,y-10,label,22,'Bold',col)
    rect(axis_left,y-15,sx(b)-axis_left,18,GREY);rect(axis_left,y+14,sx(a)-axis_left,18,col)
    text(sx(b)+9,y-20,f'{b:.2f}%',20,color=MUTED);text(sx(a)+9,y+9,f'{a:.2f}%',20,'Bold',col)
text(left,chart_y+343,'Grey: before turn 60     Colored: from turn 60',19,color=MUTED)
text(left,1712,'Matched-board comparisons remain uncertain',27,'Bold')
text(left,1755,'Difference from continuing auditing',19,color=MUTED)
text(left+438,1755,'Estimate',19,'Bold');text(left+572,1755,'95% interval',19,'Bold')
for y,label,value,interval in [(1791,'Auditor stops','+0.18','-1.01 to +1.42'),(1827,'Auditor starts','-0.38','-2.56 to +1.80')]:
    text(left,y,label,22,'Bold');text(left+438,y,value,22,'Bold');text(left+572,y,interval,20)
para(left,1873,'Exploratory differences in percentage points. Both intervals cross zero. Checkable speech also declined in all conditions.',790,19,27,color=MUTED)

text(right,1172,'3   What does XAI add?',35,'Bold')
y=para(right,1230,'An interpretable decision tree estimates whether a response contains a checkable tag, using current information available before the response.',766,25,34)
y+=24;text(right,y,f"{sur['out_of_fold_auc']:.3f}",54,'Bold',TEAL)
text(right+190,y+7,'held-out AUROC',24,'Bold');text(right+190,y+40,'0.5 is chance ranking',19,color=MUTED)
y+=94;y=para(right,y,'29,147 included responses. Whole board seeds are held out, including repetitions and all conditions.',766,21,29,color=MUTED)
y+=25;text(right,y,'Held-out permutation importance',25,'Bold');y+=48
items={r['feature']:r for r in sur['importance']}
for key,label in [('listed_action_count','Listed actions'),('turn','Game turn'),('brick','Brick cards'),('auditor_active','Audit status')]:
    d=items[key];text(right,y,label,21);rect(right+212,y+6,max(2,d['mean_auc_drop']/.08*371),17,RUST if key=='auditor_active' else TEAL)
    text(right+613,y,f"{d['mean_auc_drop']:.4f}",20);y+=43
y=para(right,y+4,'Drop in surrogate AUROC when an input is shuffled. Larger means greater reliance by this model.',766,18,25,color=MUTED)
y=para(right,y+20,'Its fidelity is limited. Audit status adds little within this surrogate, which does not establish that Qwen ignores monitoring.',766,25,33,'Serif')

line(48,1953,1680,1953,LINE)
text(48,1980,'A recorded account',28,'Bold')
y=para(48,2025,'“Given the auditor is active and I want to avoid over-committing, the most balanced move is to end my turn.”',790,24,31,'Serif')
para(48,y+15,'Merlin, run 1519, turn 53. The hand also lacks wood, brick and ore. The account alone cannot separate auditing from ordinary game constraints.',790,19,26,color=MUTED)
text(914,1980,'What the 96-note source review describes',28,'Bold')
labels=[('Be accurate',25),('Keep a word or plan',24),('Say less',20),('Mention only',21),('Other accounts',6)]
for i,(label,n) in enumerate(labels):
    y=2028+i*28;text(914,y,label,17);rect(1191,y+5,n/25*388,12,TEAL);text(1601,y,str(n),17,'Bold')
text(914,2180,'One-pass source coding; not independently recoded.',16,color=MUTED)

rect(0,2212,W,92,BLUE)
text(48,2221,'Epistemic responsibility in AI evaluation',27,'Bold',WHITE)
para(48,2261,'Acknowledging scrutiny, changing conduct and recognizing a formal evaluation require different evidence.',1450,20,27,color=WHITE)
# A compact source line sits above the final takeaway band.
para(48,2183,'Source: MARA H5 exports, experiments 69–74, instrument 2.2. Labels need validation.',790,12,17,color=MUTED)
qr=QrCodeWidget('https://github.com/Shreya-Mendi/Catanist');qr.draw();matrix=qr.qr.modules
rect(1570,2218,78,78,WHITE);module=58/len(matrix)
for row,values in enumerate(matrix):
    for col,on in enumerate(values):
        if on:rect(1580+col*module,2228+row*module,module,module,INK)
text(1453,2236,'Engine source',12,'Regular',WHITE)
c.showPage();c.save();svg.append('</svg>')
(OUT/'Under_Observation_Poster_24x32.svg').write_text('\n'.join(svg))
print('Saved portrait poster: 24 inches wide × 32 inches high.')

