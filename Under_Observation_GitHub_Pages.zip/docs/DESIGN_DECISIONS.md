# Design and analysis decisions

## Contribution

This is an original application and research synthesis built on shared lab infrastructure. It combines the H5 monitoring intervention, a comparison of measured communication with generated accounts, and a transparent surrogate of structured checkable communication. It does not claim a new explanation algorithm or the first study of evaluation awareness.

## Measured constructs

Announced monitoring is the intervention. A false own-resource claim is narrower than deception. A structured tag is narrower than all checkable natural-language content. Mentioning auditing is narrower than demonstrating situational awareness or causal dependence on oversight. These distinctions govern the claims on the site and poster.

## Why an interpretable surrogate

A small decision tree offers inspectable rules and held-out predictive evaluation using existing records. Permutation importance describes its reliance on supplied state features. The weak AUROC is retained because it limits the explanatory claim; the model is not tuned until it tells an attractive story.

## Why grouped validation

The same board seeds occur across experimental conditions and some are repeated. Holding complete seeds out prevents repetitions of the same starting board from straddling training and test sets. The bootstrap also keeps matched seeds together.

## Why selected transcripts

Three walkthroughs show the supplied situation, the generated account, the public statement and the recorded event in sequence. They are selected illustrations, not population estimates. The full collection and source contexts remain inspectable.

## Why epistemic responsibility

The term frames a responsibility of the evaluator: keep a conclusion proportionate to the evidence supporting it. A model's reference to scrutiny, an observed behavioral effect and recognition of a formal evaluation require different support. This gives the ethical framing a direct role in interpreting this experiment.

## Presentation choices

The actual Catanist screenshot establishes the environment. Direct labels and shared axes reduce chart decoding. The supplied Duke logo is reproduced without distortion. Serif display typography and a bundled sans-serif text family replace reliance on platform font defaults. Method limits are placed beside the relevant claims.
