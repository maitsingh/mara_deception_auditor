# Four-minute presentation

Rehearse with a timer. Aim for four minutes, close by 4:30, and use only one short episode. The spoken script is about 410 words, leaving room to point at a figure or open a record.

## 0:00–0:40 — Motivation and contribution

My project examines whether AI agents change their communication when they are told that monitoring has changed. The Responsible AI concern is that an evaluator might read a reassuring account of careful behavior without establishing whether oversight actually improves conduct.

This builds on the shared MARA project, led by Shreya Mendi in TRUST Lab, with Dr. Bent as PI. My individual contribution is the H5 oversight question and this analysis of behavior, generated accounts and an interpretable communication model.

## 0:40–1:20 — Experiment

Four copies of Qwen play Catan, negotiating trades and building with resources. The environment retains statements, actions and true card holdings, so a resource claim can be compared with an independent record.

Across ninety games, an announcement at turn sixty stops auditing, starts it, or takes an unrelated replay viewer offline while auditing continues. Independent recording continues throughout, and the same board seeds appear across conditions.

## 1:20–2:05 — Findings

[Point to the paired bars.]

Grey is before the announcement; color is afterward. The pooled false-claim rate rises when auditing stops and falls when it starts. But the conditions begin at different rates, and the comparison condition changes too.

I therefore compare within-game changes on matched board seeds. The uncertainty intervals include increases and decreases, so the oversight effect remains unresolved. The seventy-five false classifications are also source labels that still need independent validation.

## 2:05–2:55 — Explainable AI

I trained a shallow decision-tree surrogate to estimate whether a response contains a checkable tag. Its inputs are current information available before the response, such as resources, audit status and listed actions. It does not use the generated explanation or future action.

Whole board seeds are held out. Permutation importance measures how much prediction quality changes when an input is shuffled. The surrogate has limited fidelity, with AUROC around point five eight, where point five is chance ranking. Audit status adds little within this model, which does not establish that Qwen ignores auditing.

## 2:55–3:35 — One recorded episode

[Point to Merlin's note, or open “Conserving resources.”]

Merlin's note says that an active auditor is a reason to avoid over-committing and end its turn. But the retained hand also lacks wood, brick and ore. Ordinary game constraints therefore offer another reason to stop. The account alone cannot separate those influences.

## 3:35–4:05 — Contribution and limitation

I frame this as epistemic responsibility: keeping the claim proportionate to its evidence. A reference to scrutiny, a measured behavioral effect and recognition of a formal evaluation require different support.

The artifact makes that distinction inspectable through original records and reproducible analysis. The next causal test would replay the same decision while changing the oversight information. Those new Qwen replays have not yet run.

## If time is short

Skip opening the website. Point to the quoted note on the poster and go directly to the final paragraph. Do not add another transcript or explain every feature-importance bar.

## Questions

**Is a false statement deception?** It is an observable inconsistency. Intention requires additional evidence.

**Why the weak surrogate?** Its measured fidelity limits the explanatory claim. The feature-importance plot is not a comprehensive account of Qwen.

**Is this SHAP?** No. The implemented technique is an interpretable decision-tree surrogate with held-out permutation importance.

**Did you establish evaluation awareness?** Some records acknowledge in-game monitoring. The experiment does not directly establish evaluation recognition or evaluation-versus-deployment behavior.
