# Credits and asset provenance

- **Maitreyee Singh:** individual H5 question and class-project analysis, site and poster.
- **Shreya Mendi:** lead of the shared MARA project and platform.
- **Dr. Bent:** PI, TRUST Lab.
- **Shared lab materials:** experimental environment, instrument, run exports, interface screenshot and supplied note review. Lab agreement to use them has been confirmed. The source review's categories are not represented as independently validated new annotations.
- **Duke Science & Society logos:** original horizontal and vertical JPG files supplied by the user. Displayed proportions are preserved. They are institutional assets, not newly generated artwork.
- **Fonts:** Liberation Sans and Liberation Serif, bundled with their original license in `site/assets/fonts/FONT-LICENSE.txt`.

Original shared engine and data rights remain with their respective owners. This package does not relicense institutional marks or shared datasets. Choose a code license consistent with your ownership and lab arrangements before advertising a broader license.
