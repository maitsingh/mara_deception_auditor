# Research foundations

## Faithfulness versus plausibility

Jacovi, Alon, and Yoav Goldberg. 2020. [Towards Faithfully Interpretable NLP Systems: How Should We Define and Evaluate Faithfulness?](https://aclanthology.org/2020.acl-main.386/) ACL, 4198–4205. DOI: 10.18653/v1/2020.acl-main.386.

The paper distinguishes an explanation's persuasiveness from how accurately it reflects the model's process, and argues for explicit evaluation. This project follows that distinction by treating generated accounts as evidence to examine rather than proof of causal influence.

## Unacknowledged influences in generated explanations

Turpin, Miles, Julian Michael, Ethan Perez, and Samuel Bowman. 2023. [Language Models Don't Always Say What They Think: Unfaithful Explanations in Chain-of-Thought Prompting](https://proceedings.neurips.cc/paper_files/paper/2023/hash/ed3fea9033a80fea1376299fa7863f4a-Abstract.html). NeurIPS 36.

The authors intervene on model inputs and find cases where explanations omit influences on answers. This motivates a future controlled replay, not a claim that the present observational notes establish unfaithfulness or intentional concealment.

## Explanation accuracy and knowledge limits

Phillips, P. Jonathon, et al. 2021. [Four Principles of Explainable Artificial Intelligence](https://doi.org/10.6028/NIST.IR.8312). NISTIR 8312.

The report distinguishes understandable explanations from accurate accounts of the process and recognizes knowledge limits. Here those distinctions support displaying surrogate fidelity and separating measured conduct from generated self-report.

## Implemented methods

- [Scikit-learn decision trees](https://scikit-learn.org/stable/modules/tree.html): an inspectable probability surrogate.
- [Permutation feature importance](https://scikit-learn.org/stable/modules/permutation_importance.html): sensitivity of held-out surrogate performance to shuffling an input.
- [Grouped cross-validation](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GroupKFold.html): whole board seeds, including repeated games, remain together.

These methods describe a surrogate of recorded communication. They do not reveal Qwen activations or establish causal effects on Qwen.

## Shared environment

[Catanist](https://github.com/Shreya-Mendi/Catanist), shared MARA project, led by Shreya Mendi, TRUST Lab, PI Dr. Bent. The supplied instrument and original records, rather than claims in an earlier proposal, determine the measures used in this artifact.
